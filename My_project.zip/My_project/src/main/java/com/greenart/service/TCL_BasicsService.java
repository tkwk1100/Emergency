package com.greenart.service;

import org.springframework.stereotype.Service;

@Service
public class TCL_BasicsService {
    
}
