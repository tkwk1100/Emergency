package com.greenart.vo;

import lombok.Data;

@Data
public class EmergencyAgencyVO {
    private String ea_hpid;
    private String ea_phpid;
    private String ea_dutyEmcls;
    private String ea_dutyEmclsName;
    private String ea_dutyAddr;
    private String ea_dutyName;
    private String ea_dutyTel3;
    private String ea_region;
}
