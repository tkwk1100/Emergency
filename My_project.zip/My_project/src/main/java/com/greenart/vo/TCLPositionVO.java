package com.greenart.vo;

import lombok.Data;

@Data
public class TCLPositionVO {
    private String lon;
    private String lat;
}
