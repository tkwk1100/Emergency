package com.greenart.vo;

import lombok.Data;

@Data
public class TCL_LocationVO {
    private String dutyAddr;
    private String hpid;
    private String dutyDiv;
    private String dutyDivName;
    private String dutyName;
    private String dutyTel1;
    private String dutyFax;

    private String latitude;
    private String longitude;
}
